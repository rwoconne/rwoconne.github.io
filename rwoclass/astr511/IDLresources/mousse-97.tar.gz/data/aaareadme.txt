
   The logcial name UIT_DATA has been assigned to directories on the SUN and 
VAX for data files that need to be read by IDL.    These directories are

     VAX:  UIT$USER3:[UITMISC.DATA]
     SUN:  $IDL_HOME/data

Files include:

CSICAL.DAT  - Contain the CsI filter response curves.  Read by UITFILTER
CSTECAL.DAT  - Contain the CsTe filter response curves.  Read by UITFILTER
FRAMES.IDL - Contains image names and objects from the FRAMES database
             Read by UITDIR
HDCALIB2.DAT - Contains the UIT characteristic curve that was used in
              REV 1 (CALIB 2)
NEWHD.DAT - Contains the currently used UIT characteristic curve.  
            Read by GETHD.   Currently this is CALIB3 as used in REV 2
KUR*.INF - ASCII files listing available Kurucz models.   Read by KURUCZ
KURUCZ.MOD,KURUCZ.DAT - Contains respectively, binary files containing the
       parameters of the Kurucz models, and the Kurucz data.  Read by KURUCZ
KURUCZ_1991.MOD,KURUCZ_1991.DAT - Like above but for the new 1991 Kurucz models
M83VIS.IDL - Contain a byte visible image of M83.  Read by M83
VARIANCE.DAT - Contains the variance function of the UIT characteristic curve
               Read by FFVAR
VARIANCE_12.DAT - Old variance function for BDR stream CALIB12.

The following data files give extinction curves which are read by
UNRED.PRO.  The wavelength vector is in record 1, and the extinction
vector is in record 2.

EXTSAVMAT.TAB    ;Savage and Mathis 1979
EXTSEATON.TAB    ;Seaton 1979
EXTNANDY.TAB     ;Nandy et al 1975 
EXTORI.TAB       ;Theta 2B Orionis Bohlin & Savage 1981
EXTSMC.TAB       ;SMC Hutchings 1982
EXTLMC.TAB       ;LMC Nandy et al 1981
EXTLMC1.TAB      ;LMC Koorneef and Code 1981
EXTDOR.TAB       ;30 Dor Fitzpatrick 1985
EXTFITZ.TAB      ;LMC Fitzpatrick

The procedure OSFCNVRT (Operating System File CoNVeRT) can be used to specify
files in a operating system independent way, i.e.

     openr,1,osfcnvrt('UIT_DATA:variance.dat')


